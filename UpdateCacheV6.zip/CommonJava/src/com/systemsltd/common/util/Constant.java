package com.systemsltd.common.util;

public class Constant {
  public static final String IIB_CONFIG_DIR = "/soa/soadir/config";
  
  public static final String SRV_CONFIG_FILE_NAME = "Service.properties";
  
  public static final String PRIVATE_KEY = "key1.der";
  
  public static final String PUBLIC_KEY = "key2.der";
  
  public static final String KEY_DIRECTORY = "keys";
}
