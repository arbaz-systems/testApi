package com.systemsltd.common.util;

import java.security.PrivateKey;
import java.security.PublicKey;

public class RSACrypto {
  public static PublicKey publicKey = null;
  
  public static PrivateKey privateKey = null;
  
  public static PublicKey publicKeyVendor = null;
}
