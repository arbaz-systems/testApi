package com.systemsltd.common.util;

public class CryptoUtil {
  public static final String ALGORITHM = "RSA";
  
  public static final String ENCODING = "UTF8";
}
